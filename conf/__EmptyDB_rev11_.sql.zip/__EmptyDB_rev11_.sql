-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Апр 26 2010 г., 10:41
-- Версия сервера: 5.1.40
-- Версия PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ladder`
--

-- --------------------------------------------------------

--
-- Структура таблицы `webl_module_tournament`
--

CREATE TABLE IF NOT EXISTS `webl_module_tournament` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 - is league, 1 - is knock out',
  `name` varchar(255) NOT NULL,
  `information` text NOT NULL,
  `rules` text NOT NULL,
  `min_participants` int(11) NOT NULL,
  `max_participants` int(11) NOT NULL,
  `games_to_play` int(11) NOT NULL,
  `sign_up_starts` int(11) NOT NULL,
  `sign_up_ends` int(11) NOT NULL,
  `play_starts` int(11) NOT NULL,
  `play_ends` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

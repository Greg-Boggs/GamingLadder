-- phpMyAdmin SQL Dump
-- version 2.11.3deb1ubuntu1.1
-- http://www.phpmyadmin.net
--
-- Värd: localhost
-- Skapad: 26 september 2008 kl 20:49
-- Serverversion: 5.0.51
-- PHP-version: 5.2.4-2ubuntu5.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Databas: `subversiva_org`
--

-- --------------------------------------------------------

--
-- Struktur för tabell `webl_games`
--
-- Skapades: 26 september 2008 kl 20:47
-- Senaste uppdatering: 26 september 2008 kl 20:47
--

DROP TABLE IF EXISTS `webl_games`;
CREATE TABLE IF NOT EXISTS `webl_games` (
  `winner` varchar(40) default NULL,
  `loser` varchar(40) default NULL,
  `reported_on` datetime NOT NULL default '0000-00-00 00:00:00',
  `contested_by_loser` int(11) default '0',
  `draw` int(11) default '0',
  `withdrawn` int(11) default '0',
  `winner_elo` int(11) default NULL,
  `winner_points` int(11) default NULL,
  `winner_wins` int(11) default NULL,
  `winner_losses` int(11) default NULL,
  `winner_games` int(11) default NULL,
  `winner_streak` int(11) default NULL,
  `loser_elo` int(11) default NULL,
  `loser_points` int(11) default NULL,
  `loser_wins` int(11) default NULL,
  `loser_losses` int(11) default NULL,
  `loser_games` int(11) default NULL,
  `loser_streak` int(11) default NULL,
  `replay` longblob,
  `replay_downloads` int(11) NOT NULL default '0',
  `winner_comment` varchar(500) character set utf8 collate utf8_swedish_ci NOT NULL,
  `loser_comment` varchar(500) character set utf8 collate utf8_swedish_ci NOT NULL,
  `winner_stars` tinyint(1) default NULL COMMENT 'Sportsmanship given by loser',
  `loser_stars` tinyint(1) default NULL COMMENT 'Sportsmanship given by winner',
  PRIMARY KEY  (`reported_on`),
  KEY `games_winner` (`winner`),
  KEY `games_loser` (`loser`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data i tabell `webl_games`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `webl_news`
--
-- Skapades: 26 september 2008 kl 20:47
-- Senaste uppdatering: 26 september 2008 kl 20:47
--

DROP TABLE IF EXISTS `webl_news`;
CREATE TABLE IF NOT EXISTS `webl_news` (
  `news_id` int(10) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `date` varchar(100) default NULL,
  `news` text,
  PRIMARY KEY  (`news_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data i tabell `webl_news`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `webl_players`
--
-- Skapades: 26 september 2008 kl 20:47
-- Senaste uppdatering: 26 september 2008 kl 20:47
--

DROP TABLE IF EXISTS `webl_players`;
CREATE TABLE IF NOT EXISTS `webl_players` (
  `player_id` int(10) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `passworddb` varchar(255) default NULL,
  `approved` varchar(10) default 'no',
  `mail` varchar(50) default NULL,
  `Jabber` varchar(40) default NULL,
  `icq` varchar(15) default NULL,
  `aim` varchar(40) default NULL,
  `msn` varchar(100) default NULL,
  `country` varchar(40) default NULL,
  `ip` varchar(100) default NULL,
  `Avatar` varchar(100) default 'No avatar',
  `HaveVersion` varchar(40) default NULL,
  `MsgMe` char(3) NOT NULL default 'Yes',
  `CanPlay` text,
  `Confirmation` text NOT NULL,
  `question` text COMMENT 'The secret question for password retrieval',
  `answer` text COMMENT 'answer to the secret question',
  `Joined` int(10) default NULL,
  `Titles` varchar(160) default NULL COMMENT 'Special People',
  `active` tinyint(1) NOT NULL default '1',
  `is_admin` tinyint(1) default '0',
  PRIMARY KEY  (`player_id`),
  UNIQUE KEY `name` (`name`),
  FULLTEXT KEY `country` (`country`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Data i tabell `webl_players`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `webl_standings_cache`
--
-- Skapades: 26 september 2008 kl 20:47
-- Senaste uppdatering: 26 september 2008 kl 20:47
--

DROP TABLE IF EXISTS `webl_standings_cache`;
CREATE TABLE IF NOT EXISTS `webl_standings_cache` (
  `name` varchar(255) NOT NULL default '',
  `reported_on` datetime NOT NULL default '0000-00-00 00:00:00',
  `rating` bigint(11) default NULL,
  `wins` bigint(11) default NULL,
  `losses` bigint(11) default NULL,
  `games` bigint(11) default NULL,
  `streak` bigint(11) default NULL,
  KEY `cache_report_time` (`reported_on`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data i tabell `webl_standings_cache`
--


-- --------------------------------------------------------

--
-- Struktur för tabell `webl_waiting`
--
-- Skapades: 23 juli 2008 kl 01:01
-- Senaste uppdatering: 01 september 2008 kl 14:42
--

DROP TABLE IF EXISTS `webl_waiting`;
CREATE TABLE IF NOT EXISTS `webl_waiting` (
  `id` int(10) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL default '',
  `time` varchar(10) NOT NULL default '',
  `entered` varchar(12) NOT NULL default '',
  `meetingplace` varchar(3) default NULL,
  `rating` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Data i tabell `webl_waiting`
--


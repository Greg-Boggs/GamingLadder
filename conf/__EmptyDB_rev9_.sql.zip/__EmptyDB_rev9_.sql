-- phpMyAdmin SQL Dump
-- version 3.2.2.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 18. April 2010 um 03:01
-- Server Version: 5.1.37
-- PHP-Version: 5.2.10-2ubuntu6.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `ladder`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_cron_log`
--

CREATE TABLE IF NOT EXISTS `webl_cron_log` (
  `Cron` varchar(100) NOT NULL,
  `Time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Message` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_cron_log_2`
--

CREATE TABLE IF NOT EXISTS `webl_cron_log_2` (
  `Cron` varchar(100) NOT NULL,
  `Time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Message` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_games`
--

CREATE TABLE IF NOT EXISTS `webl_games` (
  `winner` varchar(40) DEFAULT NULL,
  `loser` varchar(40) DEFAULT NULL,
  `reported_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `contested_by_loser` int(11) DEFAULT '0',
  `draw` int(11) DEFAULT '0',
  `withdrawn` int(11) DEFAULT '0',
  `winner_elo` int(11) DEFAULT NULL,
  `winner_points` int(11) DEFAULT NULL,
  `winner_wins` int(11) DEFAULT NULL,
  `winner_losses` int(11) DEFAULT NULL,
  `winner_games` int(11) DEFAULT NULL,
  `winner_streak` int(11) DEFAULT NULL,
  `loser_elo` int(11) DEFAULT NULL,
  `loser_points` int(11) DEFAULT NULL,
  `loser_wins` int(11) DEFAULT NULL,
  `loser_losses` int(11) DEFAULT NULL,
  `loser_games` int(11) DEFAULT NULL,
  `loser_streak` int(11) DEFAULT NULL,
  `replay_downloads` int(11) NOT NULL DEFAULT '0',
  `winner_comment` varchar(500) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `loser_comment` varchar(500) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `winner_stars` tinyint(1) DEFAULT NULL COMMENT 'Sportsmanship given by loser',
  `loser_stars` tinyint(1) DEFAULT NULL COMMENT 'Sportsmanship given by winner',
  `replay_filename` varchar(20) DEFAULT NULL,
  `w_rank` int(11) NOT NULL,
  `l_rank` int(11) NOT NULL,
  `l_new_rank` int(11) NOT NULL,
  `w_new_rank` int(11) NOT NULL,
  PRIMARY KEY (`reported_on`),
  KEY `games_winner` (`winner`),
  KEY `games_loser` (`loser`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_games_2`
--

CREATE TABLE IF NOT EXISTS `webl_games_2` (
  `winner` varchar(40) DEFAULT NULL,
  `loser` varchar(40) DEFAULT NULL,
  `reported_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `contested_by_loser` int(11) DEFAULT '0',
  `draw` int(11) DEFAULT '0',
  `withdrawn` int(11) DEFAULT '0',
  `winner_elo` int(11) DEFAULT NULL,
  `winner_points` int(11) DEFAULT NULL,
  `winner_wins` int(11) DEFAULT NULL,
  `winner_losses` int(11) DEFAULT NULL,
  `winner_games` int(11) DEFAULT NULL,
  `winner_streak` int(11) DEFAULT NULL,
  `loser_elo` int(11) DEFAULT NULL,
  `loser_points` int(11) DEFAULT NULL,
  `loser_wins` int(11) DEFAULT NULL,
  `loser_losses` int(11) DEFAULT NULL,
  `loser_games` int(11) DEFAULT NULL,
  `loser_streak` int(11) DEFAULT NULL,
  `replay_downloads` int(11) NOT NULL DEFAULT '0',
  `winner_comment` varchar(500) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `loser_comment` varchar(500) CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `winner_stars` tinyint(1) DEFAULT NULL COMMENT 'Sportsmanship given by loser',
  `loser_stars` tinyint(1) DEFAULT NULL COMMENT 'Sportsmanship given by winner',
  `replay_filename` varchar(20) DEFAULT NULL,
  `w_rank` int(11) NOT NULL,
  `l_rank` int(11) NOT NULL,
  `l_new_rank` int(11) NOT NULL,
  `w_new_rank` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_module_message`
--

CREATE TABLE IF NOT EXISTS `webl_module_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `topic_id` int(11) NOT NULL COMMENT 'Refference to topic',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Message' AUTO_INCREMENT=140 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_module_topic`
--

CREATE TABLE IF NOT EXISTS `webl_module_topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(64) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `deleted_by_sender` tinyint(4) NOT NULL DEFAULT '0',
  `deleted_by_reciever` tinyint(4) NOT NULL DEFAULT '0',
  `sent_date` int(11) NOT NULL,
  `read_date` int(11) NOT NULL,
  `signature` varchar(1) NOT NULL DEFAULT 'u' COMMENT 'Message signature. Can be: u - user, a - admin. s - system, w - warning. u is default.',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_news`
--

CREATE TABLE IF NOT EXISTS `webl_news` (
  `news_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `news` text,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_news_2`
--

CREATE TABLE IF NOT EXISTS `webl_news_2` (
  `news_id` int(10) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `news` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_players`
--

CREATE TABLE IF NOT EXISTS `webl_players` (
  `player_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `passworddb` varchar(255) DEFAULT NULL,
  `approved` varchar(10) DEFAULT 'no',
  `mail` varchar(50) DEFAULT NULL,
  `Jabber` varchar(40) DEFAULT NULL,
  `icq` varchar(15) DEFAULT NULL,
  `aim` varchar(40) DEFAULT NULL,
  `msn` varchar(100) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `Avatar` varchar(100) DEFAULT 'No avatar',
  `HaveVersion` varchar(40) DEFAULT NULL,
  `MsgMe` char(3) NOT NULL DEFAULT 'Yes',
  `CanPlay` text,
  `Confirmation` text NOT NULL,
  `question` text COMMENT 'The secret question for password retrieval',
  `answer` text COMMENT 'answer to the secret question',
  `Joined` int(10) DEFAULT NULL,
  `Titles` varchar(160) DEFAULT NULL COMMENT 'Special People',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`player_id`),
  UNIQUE KEY `name` (`name`),
  FULLTEXT KEY `country` (`country`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2518 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_standings_cache`
--

CREATE TABLE IF NOT EXISTS `webl_standings_cache` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `reported_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating` bigint(11) DEFAULT NULL,
  `wins` bigint(11) DEFAULT NULL,
  `losses` bigint(11) DEFAULT NULL,
  `games` bigint(11) DEFAULT NULL,
  `streak` bigint(11) DEFAULT NULL,
  `recently_played` bigint(11) NOT NULL DEFAULT '0' COMMENT '0 if a player hasn''t played >= games within x days that are required to get a ranking. Else it displays number of games within that time span. ',
  `rank` bigint(7) NOT NULL DEFAULT '0',
  KEY `cache_report_time` (`reported_on`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_standings_cache_2`
--

CREATE TABLE IF NOT EXISTS `webl_standings_cache_2` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `reported_on` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating` bigint(11) DEFAULT NULL,
  `wins` bigint(11) DEFAULT NULL,
  `losses` bigint(11) DEFAULT NULL,
  `games` bigint(11) DEFAULT NULL,
  `streak` bigint(11) DEFAULT NULL,
  `recently_played` bigint(11) NOT NULL DEFAULT '0' COMMENT '0 if a player hasn''t played >= games within x days that are required to get a ranking. Else it displays number of games within that time span. ',
  `rank` bigint(7) NOT NULL DEFAULT '0',
  KEY `reported_on` (`reported_on`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_stats`
--

CREATE TABLE IF NOT EXISTS `webl_stats` (
  `Time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Confirmed_Players` bigint(11) NOT NULL,
  `Played_Games` bigint(11) NOT NULL,
  `Games_Today` int(11) NOT NULL,
  `Games_Recent_7` int(11) NOT NULL,
  `Games_Recent_30` int(11) NOT NULL,
  `Ranked_Players` int(11) NOT NULL,
  `Replay_Downloads` int(11) NOT NULL,
  `Games_Rated` int(11) NOT NULL,
  `Avg_Sportsmanship` float(4,3) NOT NULL,
  `Contested_Games` int(11) NOT NULL,
  `Withdrawn_Games` int(11) NOT NULL,
  `Revoked_Games` int(11) NOT NULL,
  `Commented_Games` int(11) NOT NULL,
  KEY `Time` (`Time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_stats_2`
--

CREATE TABLE IF NOT EXISTS `webl_stats_2` (
  `Time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Confirmed_Players` bigint(11) NOT NULL,
  `Played_Games` bigint(11) NOT NULL,
  `Games_Today` int(11) NOT NULL,
  `Games_Recent_7` int(11) NOT NULL,
  `Games_Recent_30` int(11) NOT NULL,
  `Ranked_Players` int(11) NOT NULL,
  `Replay_Downloads` int(11) NOT NULL,
  `Games_Rated` int(11) NOT NULL,
  `Avg_Sportsmanship` float(4,3) NOT NULL,
  `Contested_Games` int(11) NOT NULL,
  `Withdrawn_Games` int(11) NOT NULL,
  `Revoked_Games` int(11) NOT NULL,
  `Commented_Games` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_teams_2`
--

CREATE TABLE IF NOT EXISTS `webl_teams_2` (
  `team_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `approved` varchar(10) DEFAULT 'no',
  `Avatar` varchar(100) DEFAULT 'No avatar',
  `Confirmation` text NOT NULL,
  `Joined` int(10) DEFAULT NULL,
  `Titles` varchar(160) DEFAULT NULL COMMENT 'Special People',
  `player1` varchar(255) NOT NULL,
  `player2` varchar(255) NOT NULL,
  `player3` varchar(255) NOT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_waiting`
--

CREATE TABLE IF NOT EXISTS `webl_waiting` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL DEFAULT '',
  `time` varchar(10) NOT NULL DEFAULT '',
  `entered` varchar(12) NOT NULL DEFAULT '',
  `meetingplace` varchar(3) DEFAULT NULL,
  `rating` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=505 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `webl_waiting_2`
--

CREATE TABLE IF NOT EXISTS `webl_waiting_2` (
  `id` int(10) NOT NULL DEFAULT '0',
  `username` varchar(25) NOT NULL DEFAULT '',
  `time` varchar(10) NOT NULL DEFAULT '',
  `entered` varchar(12) NOT NULL DEFAULT '',
  `meetingplace` varchar(3) DEFAULT NULL,
  `rating` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
